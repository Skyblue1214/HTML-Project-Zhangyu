Zhangyu He
MASY 1240 Final Project
Professor George Pefanis




This is a website that is about sharing cars;

Several HTML features are applied:

1. Photo Gallery
2. Button
3. Video inset
4. Card with picture
5. Column and rows
6. CSS font changing
7. Footer colors
8. Divided section
9. Hyperlinked button
10. Dropdown list
11. Automatic Nav bar
12. Moving text



Thank you for teaching us!

Sincerely,

Zhangyu He, Paul
